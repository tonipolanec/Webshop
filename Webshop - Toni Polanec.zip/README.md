# Webshop
School project  
Something I'm not proud of..  
    
It's meant to be connected with database later. So it's practically ongoing project throughout school year.  
  
> index.php not in use
